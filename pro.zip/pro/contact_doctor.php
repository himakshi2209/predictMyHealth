<?php
header('Content-Type: application/json');

// Replace with your actual email address
$emailTo = 'your-email@example.com';

// Get data from POST request
$data = json_decode(file_get_contents('php://input'), true);

// Check if data is not empty
if (!empty($data['patient-name']) && !empty($data['contact-number']) && !empty($data['predicted-disease']) && !empty($data['message-to-doctor'])) {
    // Send email
    $subject = 'Contact Doctor: ' . $data['patient-name'];
    $message = 'Patient Name: ' . $data['patient-name'] . "\n";
    $message .= 'Contact Number: ' . $data['contact-number'] . "\n";
    $message .= 'Predicted Disease: ' . $data['predicted-disease'] . "\n";
    $message .= 'Message to Doctor: ' . $data['message-to-doctor'];

    if (mail($emailTo, $subject, $message)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
} else {
    echo json_encode(['success' => false]);
}
/*php
// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate input data using prepared statements and parameterized queries for improved security:
    // - Use FILTER_SANITIZE_SPECIAL_CHARS and FILTER_FLAG_STRIP_HIGH to prevent XSS and SQL injection:
    $patientName = filter_input(INPUT_POST, 'patientName', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_FLAG_STRIP_HIGH);
    $contactNumber = filter_input(INPUT_POST, 'contactNumber', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_FLAG_STRIP_HIGH);
    $predictedDisease = filter_input(INPUT_POST, 'predictedDisease', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_FLAG_STRIP_HIGH);
    $messageToDoctor = filter_input(INPUT_POST, 'messageToDoctor', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_FLAG_STRIP_HIGH);

    // - Additional validation (optional):
    //   - Check for empty fields
    //   - Validate contact number format (use regular expressions)

    // Ensure database credentials are not directly stored in the code:
    require_once 'database_credentials.php'; // Assuming a separate file with credentials

    try {
        // Connect to the database using PDO with exception handling:
        $conn = new PDO("mysql:host=$dbHost; patient", "root", "");
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare the SQL statement with placeholders for security:
        $stmt = $conn->prepare("INSERT INTO patient (patientName, contactNumber, predictedDisease, messageToDoctor) VALUES (:patientName, :contactNumber, :predictedDisease, :messageToDoctor)");

        // Bind the parameters to the placeholders:
        $stmt->bindParam(':patientName', $patientName);
        $stmt->bindParam(':contactNumber', $contactNumber);
        $stmt->bindParam(':predictedDisease', $predictedDisease);
        $stmt->bindParam(':messageToDoctor', $messageToDoctor);

        // Execute the prepared statement with bound parameters:
        $stmt->execute();

        // Success message with optional additional information:
        $message = "Message sent successfully! Your information has been stored in the database.";
        echo json_encode(['success' => true, 'message' => $message]);

    } catch(PDOException $e) {
        // Log the error for debugging and send a more informative error message:
        error_log("Error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => "Error sending message. Please try again later. Error details: " . $e->getMessage()]);
    }

    // Close the connection:
    $conn = null;
} else {
    // Handle invalid request method:
    echo json_encode(['success' => false, 'message' => "Invalid request method."]);
}
?>
