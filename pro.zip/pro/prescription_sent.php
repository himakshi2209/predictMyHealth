<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescription Sent</title>
</head>
<body>
    <h2>Prescription Sent</h2>
    <p>Thank you! Your prescription has been sent. You will receive it shortly.</p>
    <!-- You can provide additional instructions or links here -->

    <?php
    // Connect to the database
    $host = 'localhost';
    $user = 'root';
    $password = '';
    $database = 'patient';
    $conn = mysqli_connect($host, $user, $password, $database);

    // Check connection
    if (!$conn) {
        die('Connection failed: ' . mysqli_connect_error());
    }

    // Get form data
    $tests = mysqli_real_escape_string($conn, $_POST['tests']);
    $medicines = mysqli_real_escape_string($conn, $_POST['medicines']);
    $instructions = mysqli_real_escape_string($conn, $_POST['instructions']);

    // Save prescription to database
    $query = "INSERT INTO prescription (tests, medicines, instructions) VALUES ('$tests', '$medicines', '$instructions')";
    $result = mysqli_query($conn, $query);

    // Check if query was successful
    if ($result) {
        echo '<p>Prescription saved successfully.</p>';
    } else {
        echo '<p>Error saving prescription: ' . mysqli_error($conn) . '</p>';
    }

    // Close database connection
    mysqli_close($conn);
    ?>
</body>
</html>